#COMP2010 CW1 - Lexer & Parser
--------------------------------------------
> **Team:**

> - Rohan Kopparapu
> - Sam Fallahi
> - David Lipowicz

To build, issue `make`.

To test, issue `make test`.

To run on a single test file, issue `./bin/sc tests/open/<name of test>.s`

> **Will be tested with:**

> - jFlex version: 1.6.0
> - CUP version: 11b-20141204
> - Java SE 8 Update 31
> - Ubuntu 14.04.01 64bit
